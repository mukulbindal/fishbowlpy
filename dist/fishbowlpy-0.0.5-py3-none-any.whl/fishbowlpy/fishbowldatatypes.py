class FishBowlResponse:
    headers = None
    data = None